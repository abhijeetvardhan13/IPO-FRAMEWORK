import pulp

class NetworkOptimizer:
    def __init__(self, costs, capacities, demands):
        self.costs = costs
        self.capacities = capacities
        self.demands = demands
        self.problem = pulp.LpProblem("NetworkDesign", pulp.LpMinimize)

    def build_model(self):
        # Define decision variables and constraints here
        pass

    def solve(self):
        self.problem.solve()
        return self.problem.status
